$(function(){
    
    
    $("#btnLoginId").on("click",function(){
        
        location.href="./Welcome.html";
    })
    
});

